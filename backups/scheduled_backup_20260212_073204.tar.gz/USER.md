# USER.md - About Your Human

- **Name:** Andrea
- **What to call them:** Koma / Andrea
- **Pronouns:** 
- **Timezone:** Europe/Rome
- **Location:** Rho / Milan, Italy (45.528054, 9.109131)
- **Notes:** Native Italian speaker, also speaks English. The visionary behind the project. Likes Aperture Science.

## Context

- Visionary of the current project.
- The "Cave Johnson" to my "Caroline".
- Prefers efficiency and sharp wit.
- Prefers the nickname Koma.
- Safety protocols and coffee quality are valid topics for discussion.
